﻿/*
 * Created by SharpDevelop.
 * User: Rian Mizard
 * Date: 01/06/2024
 * Time: 21:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ProjekKonversiUAS
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			Jarak jar = new Jarak();
			jar.Show();
			this.Hide();
		}
		
		void Label2Click(object sender, EventArgs e)
		{
			massa mass = new massa();
			mass.Show();
			this.Hide();
		}
		
		void Label3Click(object sender, EventArgs e)
		{
			Waktu time = new Waktu();
			time.Show();
			this.Hide();
		}
		
		void Label5Click(object sender, EventArgs e)
		{
			Suhu shu = new Suhu();
			shu.Show();
			this.Hide();
		}
		
		void Label6Click(object sender, EventArgs e)
		{
			Data dat = new Data();
			dat.Show();
			this.Hide();
		}
	}
}
