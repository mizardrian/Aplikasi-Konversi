﻿/*
 * Created by SharpDevelop.
 * User: Rian Mizard
 * Date: 01/06/2024
 * Time: 23:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace ProjekKonversiUAS
{
	partial class Data
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Data));
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.btnback = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(63, 133);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(477, 20);
			this.textBox1.TabIndex = 0;
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
									"Bit",
									"Byte",
									"KB",
									"MB",
									"GB",
									"TB"});
			this.comboBox1.Location = new System.Drawing.Point(63, 178);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(477, 21);
			this.comboBox1.TabIndex = 1;
			// 
			// comboBox2
			// 
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Items.AddRange(new object[] {
									"Bit",
									"Byte",
									"KB",
									"MB",
									"GB",
									"TB"});
			this.comboBox2.Location = new System.Drawing.Point(63, 225);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(477, 21);
			this.comboBox2.TabIndex = 2;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.Lime;
			this.button1.Location = new System.Drawing.Point(63, 256);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(160, 23);
			this.button1.TabIndex = 3;
			this.button1.Text = "KONVERSI";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(355, 259);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(185, 20);
			this.textBox2.TabIndex = 4;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(294, 259);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(46, 20);
			this.label1.TabIndex = 5;
			this.label1.Text = "Hasil :";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(63, 111);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(235, 19);
			this.label2.TabIndex = 6;
			this.label2.Text = "Silahkan masukkan angka yang ingin dikoversi :";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(63, 156);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(160, 19);
			this.label3.TabIndex = 7;
			this.label3.Text = "Data awal yang ingin dikonversi :";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(63, 204);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(145, 18);
			this.label4.TabIndex = 8;
			this.label4.Text = "Data yang ingin dikonversi :";
			// 
			// btnback
			// 
			this.btnback.BackColor = System.Drawing.Color.Yellow;
			this.btnback.Location = new System.Drawing.Point(58, 372);
			this.btnback.Name = "btnback";
			this.btnback.Size = new System.Drawing.Size(165, 23);
			this.btnback.TabIndex = 9;
			this.btnback.Text = "Menu Utama";
			this.btnback.UseVisualStyleBackColor = false;
			this.btnback.Click += new System.EventHandler(this.BtnbackClick);
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(228, 43);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(178, 23);
			this.label5.TabIndex = 12;
			this.label5.Text = "KONVERSI DATA";
			// 
			// label6
			// 
			this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
			this.label6.Location = new System.Drawing.Point(89, 9);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(110, 92);
			this.label6.TabIndex = 13;
			// 
			// Data
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(569, 431);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.btnback);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.comboBox2);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.textBox1);
			this.Name = "Data";
			this.Text = "Data";
			this.Load += new System.EventHandler(this.DataLoad);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnback;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.TextBox textBox1;
	}
}
