﻿/*
 * Created by SharpDevelop.
 * User: Rian Mizard
 * Date: 01/06/2024
 * Time: 23:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProjekKonversiUAS
{
	/// <summary>
	/// Description of Data.
	/// </summary>
	public partial class Data : Form
	{
		public Data()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			string value1 = comboBox1.SelectedItem.ToString();
string value2 = comboBox2.SelectedItem.ToString();

double num = double.Parse(textBox1.Text);
double hasil = 0;

string[] unit = { "Bit", "Byte", "KB", "MB", "GB", "TB" };
double[] multipliers = { 1, 8, 8 * 1024, 8 * 1024 * 1024, 8.0 * 1024 * 1024 * 1024, 8.0 * 1024 * 1024 * 1024 * 1024 };

int indexvalue1 = Array.IndexOf(unit, value1);
int indexvalue2 = Array.IndexOf(unit, value2);

if (indexvalue1 >= 0 && indexvalue2 >= 0) {
    hasil = num * (multipliers[indexvalue1] / multipliers[indexvalue2]);
}

textBox2.Text = String.Format("{0} {1}", hasil, value2);


		}
		
		void DataLoad(object sender, EventArgs e)
		{
			
		}
		
		void BtnbackClick(object sender, EventArgs e)
		{
			MainForm utama = new MainForm();
			utama.Show();
			this.Hide();
		}
	}
}
