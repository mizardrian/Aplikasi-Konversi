﻿/*
 * Created by SharpDevelop.
 * User: Rian Mizard
 * Date: 01/06/2024
 * Time: 23:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProjekKonversiUAS
{
	/// <summary>
	/// Description of Suhu.
	/// </summary>
	public partial class Suhu : Form
	{
		public Suhu()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			string value1 = comboBox1.SelectedItem.ToString();
			string value2 = comboBox2.SelectedItem.ToString();

			double num = double.Parse(textBox1.Text);
			double hasil = 0;

			if (value1 == "Celsius")
			{
    			if (value2 == "Celsius")
    				{
        				hasil = num;
    				}
    			else if (value2 == "Fahrenheit")
    				{
        				hasil = (num * 9 / 5) + 32;
    				}
    			else if (value2 == "Kelvin")
    				{
        				hasil = num + 273.15;
    				}
			}
			else if (value1 == "Fahrenheit")
			{
    			if (value2 == "Celsius")
    				{
        				hasil = (num - 32) * 5 / 9;
    				}
    			else if (value2 == "Fahrenheit")
    				{
        				hasil = num;
    				}
    					else if (value2 == "Kelvin")
    				{
        				hasil = (num - 32) * 5 / 9 + 273.15;
    				}
			}
			else if (value1 == "Kelvin")
				{
   				if (value2 == "Celsius")
    			{
        			hasil = num - 273.15;
    			}
    			else if (value2 == "Fahrenheit")
    			{
        			hasil = (num - 273.15) * 9 / 5 + 32;
    			}
    				else if (value2 == "Kelvin")
    			{
        			hasil = num;
    			}
			}
			textBox2.Text = String.Format("{0} {1}", hasil, value2);

		}
		
		void SuhuLoad(object sender, EventArgs e)
		{
			
		}
		
		void Label4Click(object sender, EventArgs e)
		{
			
		}
		
		void BtnbackClick(object sender, EventArgs e)
		{
			MainForm utama = new MainForm();
			utama.Show();
			this.Hide();
		}
	}
}
