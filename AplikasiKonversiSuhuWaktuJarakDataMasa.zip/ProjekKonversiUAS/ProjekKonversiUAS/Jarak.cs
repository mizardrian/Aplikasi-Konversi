﻿/*
 * Created by SharpDevelop.
 * User: Rian Mizard
 * Date: 01/06/2024
 * Time: 21:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProjekKonversiUAS
{
	/// <summary>
	/// Description of Jarak.
	/// </summary>
	public partial class Jarak : Form
	{
		public Jarak()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnbackClick(object sender, EventArgs e)
		{
			MainForm utama = new MainForm();
			utama.Show();
			this.Hide();
		}
		
		void BtnkonversiClick(object sender, EventArgs e)
		{
			string value1 = comboBox1.SelectedItem.ToString();
			string value2 = comboBox2.SelectedItem.ToString();

			double num = double.Parse(textBox1.Text);
			double hasil = 0;
			string[] unit =  { "KM", "HM", "DAM", "M", "DM", "CM", "MM"};
			double[] multipliers = { 1000, 100, 10, 1, 0.1, 0.01, 0.001};

			int indexvalue1 = Array.IndexOf(unit, value1);
			int indexvalue2 = Array.IndexOf(unit, value2);

			if (indexvalue1 >= 0 && indexvalue2 >= 0) {
  					hasil = num * (multipliers[indexvalue1] / multipliers[indexvalue2]);
			}
			textBox2.Text = String.Format("{0} {1}", hasil, value2);
		}
		
		
	}
}
